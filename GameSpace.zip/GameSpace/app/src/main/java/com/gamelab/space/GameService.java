package com.gamelab.space;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.widget.Toast;

import java.util.Locale;

/**
 * Owns one gaming session: applies the profile, watches which app is in front,
 * shows the in-game dock, applies the thermal guard, and restores everything
 * automatically when the game is no longer the foreground app.
 */
public class GameService extends Service {

    static final String ACTION_PLAY = "com.gamelab.space.PLAY";
    static final String ACTION_END = "com.gamelab.space.END";
    static final String EXTRA_PKG = "pkg";
    static volatile boolean running;

    private static final String CH = "session";
    private static final int NOTIF_ID = 1;
    private static final long POLL_MS = 2000, START_TIMEOUT_MS = 30000, GUARD_COOLDOWN_MS = 90000;

    private final Handler h = new Handler(Looper.getMainLooper());
    private UsageStatsManager usm;
    private Profile prof;
    private Overlay overlay;
    private boolean seen, ending;
    private long startT, awayT, lastGuard, lastNotif, lastQuery;
    private String fg = "";

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        usm = getSystemService(UsageStatsManager.class);
        getSystemService(NotificationManager.class).createNotificationChannel(
                new NotificationChannel(CH, "Game session", NotificationManager.IMPORTANCE_LOW));
    }

    @Override
    public void onDestroy() {
        running = false;
        h.removeCallbacksAndMessages(null);
        if (overlay != null) overlay.hide();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String act = intent == null ? null : intent.getAction();
        startForeground(NOTIF_ID, notif(prof == null ? "Preparing…" : "Game Space"));

        if (ACTION_END.equals(act)) {
            if (prof == null) { endNoProfile(); } else { endSession("Reset"); }
            return START_NOT_STICKY;
        }
        if (ACTION_PLAY.equals(act) && prof == null) {
            final Profile p = Store.find(this, intent.getStringExtra(EXTRA_PKG));
            if (p == null) { stopSelf(); return START_NOT_STICKY; }
            prof = p;
            seen = false;
            ending = false;
            startForeground(NOTIF_ID, notif("Boosting for " + p.label + "…"));
            ShizukuHelper.with(s -> {
                Engine.apply(this, s, p);
                h.post(() -> beginMonitoring());
            }, e -> h.post(() -> {
                toast("Boost failed: " + e);
                prof = null;
                stopForeground(true);
                stopSelf();
            }));
        } else if (prof == null) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    // ------------------------------------------------------------ monitoring
    private void beginMonitoring() {
        startT = SystemClock.elapsedRealtime();
        lastQuery = System.currentTimeMillis() - 5000;
        boolean dock = Store.sp(this).getBoolean("overlay", true) && Settings.canDrawOverlays(this);
        if (dock) {
            overlay = new Overlay(this, new Overlay.Actions() {
                @Override public void res(int idx) {
                    ShizukuHelper.with(s -> Engine.setWidth(GameService.this, s, idx, prof.dens), e -> {});
                }
                @Override public void clearRam() {
                    ShizukuHelper.with(s -> {
                        int n = Engine.killOthers(GameService.this, s, prof.pkg);
                        h.post(() -> toast("Closed " + n + " apps"));
                    }, e -> {});
                }
                @Override public void dnd() {
                    boolean now = overlayDnd = !overlayDnd;
                    ShizukuHelper.with(s -> Engine.setDnd(GameService.this, s, now), e -> {});
                }
                @Override public void end() { h.post(() -> endSession("Reset")); }
            }, (prof.flags & Engine.F_DND) != 0);
            overlayDnd = (prof.flags & Engine.F_DND) != 0;
            overlay.setCurrent(Store.sp(this).getInt("curres", prof.res));
        }
        startForeground(NOTIF_ID, notif("Waiting for " + prof.label));
        h.postDelayed(poll, 1500);
    }

    private boolean overlayDnd;

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (ending || prof == null) return;
            long now = SystemClock.elapsedRealtime();
            readForeground();
            boolean inGame = prof.pkg.equals(fg);

            if (inGame) {
                seen = true;
                awayT = 0;
                if (overlay != null) {
                    overlay.show();
                    overlay.setCurrent(Store.sp(GameService.this).getInt("curres", prof.res));
                    overlay.setStats(String.format(Locale.US, "%.1f°C   RAM free %d MB   Batt %d%%",
                            Sys.tempC(GameService.this), Sys.ramFreeMb(), Sys.battPct(GameService.this)));
                }
                thermalGuard(now);
            } else {
                if (overlay != null) overlay.hide();
                if (!seen) {
                    if (now - startT > START_TIMEOUT_MS) { endSession("Game didn't start"); return; }
                } else {
                    if (awayT == 0) awayT = now;
                    long grace = Store.sp(GameService.this).getInt("grace", 8) * 1000L;
                    if (now - awayT > grace) { endSession("Game closed"); return; }
                }
            }

            if (now - lastNotif > 10000) {
                lastNotif = now;
                getSystemService(NotificationManager.class).notify(NOTIF_ID, notif(
                        String.format(Locale.US, "%s · %.1f°C", prof.label, Sys.tempC(GameService.this))));
            }
            h.postDelayed(this, POLL_MS);
        }
    };

    private void readForeground() {
        long now = System.currentTimeMillis();
        try {
            UsageEvents ev = usm.queryEvents(lastQuery, now);
            UsageEvents.Event e = new UsageEvents.Event();
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e);
                if (e.getEventType() == UsageEvents.Event.ACTIVITY_RESUMED) fg = e.getPackageName();
            }
        } catch (SecurityException ignored) {}
        lastQuery = now - 500;
    }

    private void thermalGuard(long now) {
        if (!Store.sp(this).getBoolean("thermal", true)) return;
        if (now - lastGuard < GUARD_COOLDOWN_MS) return;
        int limit = Store.sp(this).getInt("tlimit", 42);
        if (Sys.tempC(this) < limit) return;
        int cur = Store.sp(this).getInt("curres", prof.res);
        if (cur >= Engine.WIDTHS.length - 1) return;
        final int next = cur + 1;
        lastGuard = now;
        ShizukuHelper.with(s -> {
            Engine.setWidth(this, s, next, prof.dens);
            h.post(() -> {
                toast("Thermal guard: " + Engine.RES_NAMES[next]);
                if (overlay != null) overlay.setCurrent(next);
            });
        }, e -> {});
    }

    // ------------------------------------------------------------ ending
    private void endSession(final String reason) {
        if (ending) return;
        ending = true;
        h.removeCallbacks(poll);
        if (overlay != null) overlay.hide();
        startForeground(NOTIF_ID, notif("Restoring your settings…"));
        ShizukuHelper.with(s -> {
            Engine.restore(this, s);
            h.post(() -> { toast(reason + " — settings restored"); finishService(); });
        }, e -> h.post(() -> {
            toast("Couldn't restore (open Game Space to retry): " + e);
            finishService();
        }));
    }

    /** Reset requested while no session object exists (e.g. notification after a crash). */
    private void endNoProfile() {
        ending = true;
        ShizukuHelper.with(s -> {
            Engine.restore(this, s);
            h.post(() -> { toast("Settings restored"); finishService(); });
        }, e -> h.post(this::finishService));
    }

    private void finishService() {
        prof = null;
        stopForeground(true);
        stopSelf();
    }

    private Notification notif(String text) {
        int fl = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), fl);
        PendingIntent end = PendingIntent.getForegroundService(this, 1,
                new Intent(this, GameService.class).setAction(ACTION_END), fl);
        return new Notification.Builder(this, CH)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Game Space")
                .setContentText(text)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(0, "Reset now", end).build())
                .setOngoing(true)
                .build();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
