package com.gamelab.space;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

final class Store {

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("gs", Context.MODE_PRIVATE);
    }

    static List<Profile> games(Context c) {
        List<Profile> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString("games", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Profile p = new Profile();
                p.pkg = o.getString("pkg");
                p.label = o.optString("label", p.pkg);
                p.res = o.optInt("res", 1);
                p.dens = o.optBoolean("dens", true);
                p.flags = o.optInt("flags", Engine.DEFAULT_FLAGS);
                if (p.res < 0 || p.res >= Engine.WIDTHS.length) p.res = 1;
                out.add(p);
            }
        } catch (JSONException ignored) {}
        return out;
    }

    private static void saveAll(Context c, List<Profile> list) {
        JSONArray a = new JSONArray();
        for (Profile p : list) {
            try {
                JSONObject o = new JSONObject();
                o.put("pkg", p.pkg);
                o.put("label", p.label);
                o.put("res", p.res);
                o.put("dens", p.dens);
                o.put("flags", p.flags);
                a.put(o);
            } catch (JSONException ignored) {}
        }
        sp(c).edit().putString("games", a.toString()).apply();
    }

    static Profile find(Context c, String pkg) {
        for (Profile p : games(c)) if (p.pkg.equals(pkg)) return p;
        return null;
    }

    static void upsert(Context c, Profile np) {
        List<Profile> l = games(c);
        boolean found = false;
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i).pkg.equals(np.pkg)) { l.set(i, np); found = true; break; }
        }
        if (!found) l.add(np);
        saveAll(c, l);
    }

    static void remove(Context c, String pkg) {
        List<Profile> l = games(c);
        for (int i = 0; i < l.size(); i++) if (l.get(i).pkg.equals(pkg)) { l.remove(i); break; }
        saveAll(c, l);
    }
}
