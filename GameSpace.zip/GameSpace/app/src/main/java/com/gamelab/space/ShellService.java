package com.gamelab.space;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/** Runs inside the Shizuku-spawned shell process. */
public class ShellService extends IShellService.Stub {

    public ShellService() {}

    @Override
    public void destroy() { System.exit(0); }

    @Override
    public String exec(String command) {
        try {
            Process p = new ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start();
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append('\n');
            }
            p.waitFor();
            return sb.toString();
        } catch (Exception e) {
            return "ERR: " + e;
        }
    }
}
