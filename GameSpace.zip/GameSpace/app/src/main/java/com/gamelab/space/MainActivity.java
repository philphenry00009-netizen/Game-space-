package com.gamelab.space;

import android.Manifest;
import android.app.Activity;
import android.app.AppOpsManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    private static final int BG = 0xFF0A0A0C, CARD = 0xFF17171C, CARD2 = 0xFF22222A,
            RED = 0xFFFF2D4A, DIM = 0xFF8A8A96, GREEN = 0xFF00E676, AMBER = 0xFFFFB300;
    private static final int REQ_SHIZUKU = 1;

    private static final String[] HINTS = {
            "Full detail. Heaviest on GPU and battery.",
            "Balanced: sharp enough, much lighter.",
            "Fast: noticeably softer, big GPU saving.",
            "Faster: soft image, very smooth.",
            "Pixel mode: chunky blocks, maximum FPS and coolest phone."};

    private static final class App { String pkg, label; Drawable icon; }

    private SharedPreferences sp;
    private int screen;               // 0 home, 1 game, 2 picker, 3 settings
    private TextView tTemp, tRam, tBatt, tLog;
    private List<App> appCache;

    private final Shizuku.OnBinderReceivedListener onBinder = () -> runOnUiThread(this::softRefresh);
    private final Shizuku.OnBinderDeadListener onDead = () -> runOnUiThread(this::softRefresh);
    private final Shizuku.OnRequestPermissionResultListener onPerm = (c, r) -> runOnUiThread(this::softRefresh);
    private final BroadcastReceiver battReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { stats(); }
    };

    // ============================================================ lifecycle
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = Store.sp(this);
        Shizuku.addBinderReceivedListenerSticky(onBinder);
        Shizuku.addBinderDeadListener(onDead);
        Shizuku.addRequestPermissionResultListener(onPerm);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 0);
        }
        home();
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter f = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(battReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(battReceiver, f);
        recoverIfNeeded();
        if (screen == 0) home();
    }

    @Override
    protected void onPause() {
        try { unregisterReceiver(battReceiver); } catch (Exception ignored) {}
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        Shizuku.removeBinderReceivedListener(onBinder);
        Shizuku.removeBinderDeadListener(onDead);
        Shizuku.removeRequestPermissionResultListener(onPerm);
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (screen != 0) home(); else super.onBackPressed();
    }

    private void softRefresh() { if (screen == 0) home(); }

    /** A session flagged active with no service running means a crash/reboot: put the phone back. */
    private void recoverIfNeeded() {
        if (sp.getBoolean("active", false) && !GameService.running && ShizukuHelper.granted()) {
            ShizukuHelper.with(s -> {
                Engine.restore(this, s);
                runOnUiThread(() -> { log("Previous session was restored to normal."); softRefresh(); });
            }, e -> {});
        }
    }

    // ============================================================ permissions / state
    private boolean overlayOk() { return Settings.canDrawOverlays(this); }

    private boolean usageOk() {
        AppOpsManager ao = getSystemService(AppOpsManager.class);
        return ao.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName())
                == AppOpsManager.MODE_ALLOWED;
    }

    private void setupAction() {
        if (!ShizukuHelper.running()) {
            Intent i = getPackageManager().getLaunchIntentForPackage(Engine.SHIZUKU);
            if (i != null) startActivity(i); else log("Install and start Shizuku first.");
            return;
        }
        if (!ShizukuHelper.granted()) { Shizuku.requestPermission(REQ_SHIZUKU); return; }
        final String me = getPackageName();
        log("Granting permissions…");
        ShizukuHelper.with(s -> {
            s.exec("appops set " + me + " SYSTEM_ALERT_WINDOW allow; "
                 + "appops set " + me + " GET_USAGE_STATS allow; "
                 + "pm grant " + me + " android.permission.POST_NOTIFICATIONS 2>/dev/null; "
                 + "cmd deviceidle whitelist +" + me + " 2>/dev/null");
            runOnUiThread(() -> { log("Permissions granted."); softRefresh(); });
        }, e -> runOnUiThread(() -> log("Error: " + e)));
    }

    private void play(Profile p) {
        if (!ShizukuHelper.granted()) { log("Shizuku isn't ready. Go back and finish setup."); return; }
        if (!usageOk()) { log("Usage access missing. Go back and tap the setup button."); return; }
        if (getPackageManager().getLaunchIntentForPackage(p.pkg) == null) { log("This game isn't installed anymore."); return; }
        if (GameService.running) { log("A session is already running."); return; }
        Store.upsert(this, p);
        startForegroundService(new Intent(this, GameService.class)
                .setAction(GameService.ACTION_PLAY).putExtra(GameService.EXTRA_PKG, p.pkg));
        log("Boosting…");
    }

    private void resetNow() {
        if (GameService.running) {
            startForegroundService(new Intent(this, GameService.class).setAction(GameService.ACTION_END));
            log("Restoring…");
        } else {
            ShizukuHelper.with(s -> {
                Engine.restore(this, s);
                runOnUiThread(() -> { log("Everything restored to normal."); softRefresh(); });
            }, e -> runOnUiThread(() -> log("Error: " + e)));
        }
    }

    // ============================================================ HOME
    private void home() {
        screen = 0;
        LinearLayout root = page();

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView t = tv("GAME SPACE", 26, Color.WHITE, true);
        t.setLetterSpacing(0.12f);
        titles.addView(t);
        titles.addView(tv("Tune. Play. Auto-reset.", 12, DIM, false));
        head.addView(titles, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Button gear = btn("⚙", CARD, Color.WHITE);
        gear.setOnClickListener(v -> settings());
        head.addView(gear, new LinearLayout.LayoutParams(dp(52), dp(48)));
        root.addView(head);

        // live stats
        LinearLayout strip = new LinearLayout(this);
        strip.setBackground(rr(CARD, 14));
        strip.setPadding(dp(8), dp(14), dp(8), dp(14));
        tTemp = stat(strip, "TEMP");
        tRam = stat(strip, "RAM FREE");
        tBatt = stat(strip, "BATTERY");
        root.addView(strip, lp(dp(16)));
        stats();

        // setup card
        boolean run = ShizukuHelper.running(), ok = ShizukuHelper.granted();
        boolean ov = overlayOk(), us = usageOk();
        if (!(ok && ov && us)) {
            LinearLayout card = card(CARD);
            card.addView(tv("SETUP", 11, DIM, true));
            card.addView(tv(dot("Shizuku running", run) + dot("Shizuku permission", ok)
                    + dot("Overlay (in-game dock)", ov) + dot("Usage access (auto-reset)", us),
                    13, Color.WHITE, false), lp(dp(6)));
            Button b = btn(!run ? "Open Shizuku" : !ok ? "Allow Shizuku access" : "Grant overlay + usage access",
                    RED, Color.WHITE);
            b.setOnClickListener(v -> setupAction());
            card.addView(b, lp(dp(10)));
            root.addView(card, lp(dp(12)));
        }

        // active session
        if (sp.getBoolean("active", false)) {
            LinearLayout card = card(0xFF2A0F16);
            card.addView(tv("SESSION ACTIVE", 11, RED, true));
            card.addView(tv("Boosted. Your normal settings come back automatically when the game closes.",
                    13, Color.WHITE, false), lp(dp(4)));
            Button b = btn("Reset to normal now", AMBER, Color.BLACK);
            b.setOnClickListener(v -> resetNow());
            card.addView(b, lp(dp(10)));
            root.addView(card, lp(dp(12)));
        }

        // games
        root.addView(tv("MY GAMES", 11, DIM, true), lp(dp(22)));
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(3);
        for (final Profile p : Store.games(this)) {
            LinearLayout tile = tile();
            ImageView ic = new ImageView(this);
            try { ic.setImageDrawable(getPackageManager().getApplicationIcon(p.pkg)); } catch (Exception ignored) {}
            tile.addView(ic, new LinearLayout.LayoutParams(dp(56), dp(56)));
            TextView n = tv(p.label, 11, Color.WHITE, false);
            n.setMaxLines(1); n.setEllipsize(TextUtils.TruncateAt.END); n.setGravity(Gravity.CENTER);
            tile.addView(n, lp(dp(6)));
            tile.setOnClickListener(v -> gameScreen(p));
            grid.addView(tile, tileLp());
        }
        LinearLayout add = tile();
        TextView plus = tv("+", 34, RED, true);
        plus.setGravity(Gravity.CENTER);
        add.addView(plus, new LinearLayout.LayoutParams(dp(56), dp(56)));
        add.addView(tv("Add game", 11, DIM, false), lp(dp(6)));
        add.setOnClickListener(v -> picker());
        grid.addView(add, tileLp());
        root.addView(grid, lp(dp(8)));

        tLog = tv("", 12, DIM, false);
        root.addView(tLog, lp(dp(16)));
        show(root);
    }

    private TextView stat(LinearLayout strip, String label) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        TextView v = tv("—", 18, Color.WHITE, true);
        v.setGravity(Gravity.CENTER);
        col.addView(v);
        TextView l = tv(label, 10, DIM, true);
        l.setGravity(Gravity.CENTER);
        col.addView(l);
        strip.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        return v;
    }

    private void stats() {
        if (screen != 0 || tTemp == null) return;
        float t = Sys.tempC(this);
        tTemp.setText(t < 0 ? "—" : String.format(Locale.US, "%.1f°", t));
        tTemp.setTextColor(t >= 42 ? RED : t >= 39 ? AMBER : GREEN);
        long r = Sys.ramFreeMb();
        tRam.setText(r < 0 ? "—" : String.format(Locale.US, "%.1f GB", r / 1024f));
        tBatt.setText(Sys.battPct(this) + "%");
    }

    private static String dot(String label, boolean v) { return (v ? "●  " : "○  ") + label + "\n"; }

    // ============================================================ GAME PROFILE
    private void gameScreen(final Profile p) {
        screen = 1;
        LinearLayout root = page();
        root.addView(back());

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView ic = new ImageView(this);
        try { ic.setImageDrawable(getPackageManager().getApplicationIcon(p.pkg)); } catch (Exception ignored) {}
        head.addView(ic, new LinearLayout.LayoutParams(dp(56), dp(56)));
        TextView name = tv(p.label, 22, Color.WHITE, true);
        name.setPadding(dp(14), 0, 0, 0);
        head.addView(name);
        root.addView(head, lp(dp(10)));

        root.addView(tv("RESOLUTION", 11, DIM, true), lp(dp(20)));
        final TextView hint = tv(HINTS[p.res], 12, DIM, false);
        final Button[] chips = new Button[Engine.WIDTHS.length];
        LinearLayout row = new LinearLayout(this);
        for (int i = 0; i < chips.length; i++) {
            final int idx = i;
            Button b = btn(Engine.RES_NAMES[i], CARD, Color.WHITE);
            b.setTextSize(12);
            b.setMinWidth(0); b.setMinimumWidth(0);
            b.setPadding(0, 0, 0, 0);
            b.setOnClickListener(v -> {
                p.res = idx; Store.upsert(this, p);
                for (int k = 0; k < chips.length; k++) chips[k].setBackground(rr(k == idx ? RED : CARD, 10));
                hint.setText(HINTS[idx]);
            });
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, dp(44), 1f);
            l.rightMargin = dp(4);
            row.addView(b, l);
            chips[i] = b;
            b.setBackground(rr(i == p.res ? RED : CARD, 10));
        }
        root.addView(row, lp(dp(6)));
        root.addView(hint, lp(dp(6)));

        root.addView(flagSwitch("Scale density with resolution (keeps UI size)", p, 0), lp(dp(6)));

        root.addView(tv("BOOST OPTIONS", 11, DIM, true), lp(dp(18)));
        root.addView(flagSwitch("Close all other apps", p, Engine.F_KILLALL));
        root.addView(flagSwitch("Clear cached background processes", p, Engine.F_KILL));
        root.addView(flagSwitch("Game Mode: performance (if supported)", p, Engine.F_GAME));
        root.addView(flagSwitch("Sustained performance mode (if supported)", p, Engine.F_SUST));
        root.addView(flagSwitch("Do Not Disturb", p, Engine.F_DND));
        root.addView(flagSwitch("Disable window blur", p, Engine.F_BLUR));
        root.addView(flagSwitch("Turn off system animations", p, Engine.F_ANIM));
        root.addView(flagSwitch("Disable battery saver & adaptive battery", p, Engine.F_BATT));
        root.addView(flagSwitch("Lock brightness (disable auto)", p, Engine.F_BRIGHT));
        root.addView(flagSwitch("Keep screen on (30 min timeout)", p, Engine.F_SCREEN));

        Button play = btn("PLAY", RED, Color.WHITE);
        play.setTextSize(18);
        play.setTypeface(Typeface.DEFAULT_BOLD);
        play.setOnClickListener(v -> play(p));
        root.addView(play, lp(dp(60), dp(22)));

        Button rm = btn("Remove from Game Space", BG, DIM);
        rm.setOnClickListener(v -> { Store.remove(this, p.pkg); home(); });
        root.addView(rm, lp(dp(8)));

        tLog = tv("", 12, DIM, false);
        root.addView(tLog, lp(dp(10)));
        show(root);
    }

    /** flag == 0 means the "scale density" boolean. */
    private Switch flagSwitch(String label, final Profile p, final int flag) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextColor(Color.WHITE);
        s.setTextSize(14);
        s.setPadding(0, dp(9), 0, dp(9));
        s.setChecked(flag == 0 ? p.dens : (p.flags & flag) != 0);
        s.setOnCheckedChangeListener((b, on) -> {
            if (flag == 0) p.dens = on;
            else p.flags = on ? (p.flags | flag) : (p.flags & ~flag);
            Store.upsert(this, p);
        });
        return s;
    }

    // ============================================================ PICKER
    private void picker() {
        screen = 2;
        LinearLayout root = page();
        root.addView(back());
        root.addView(tv("Add a game", 22, Color.WHITE, true), lp(dp(10)));

        final EditText search = new EditText(this);
        search.setHint("Search apps");
        search.setHintTextColor(DIM);
        search.setTextColor(Color.WHITE);
        search.setBackground(rr(CARD, 12));
        search.setPadding(dp(14), dp(12), dp(14), dp(12));
        search.setSingleLine(true);
        root.addView(search, lp(dp(12)));

        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list, lp(dp(8)));
        list.addView(tv("Loading…", 13, DIM, false));
        show(root);

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable e) { fill(list, e.toString()); }
        });

        new Thread(() -> {
            List<App> apps = loadApps();
            runOnUiThread(() -> { appCache = apps; fill(list, search.getText().toString()); });
        }).start();
    }

    private List<App> loadApps() {
        PackageManager pm = getPackageManager();
        Set<String> have = new HashSet<>();
        for (Profile p : Store.games(this)) have.add(p.pkg);
        List<App> out = new ArrayList<>();
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo ri : pm.queryIntentActivities(i, 0)) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || have.contains(pkg)) continue;
            App a = new App();
            a.pkg = pkg;
            a.label = String.valueOf(ri.loadLabel(pm));
            a.icon = ri.loadIcon(pm);
            out.add(a);
        }
        Collections.sort(out, (x, y) -> x.label.compareToIgnoreCase(y.label));
        return out;
    }

    private void fill(LinearLayout list, String q) {
        list.removeAllViews();
        if (appCache == null) return;
        String f = q.toLowerCase(Locale.ROOT).trim();
        for (final App a : appCache) {
            if (!f.isEmpty() && !a.label.toLowerCase(Locale.ROOT).contains(f)) continue;
            LinearLayout r = new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(4), dp(10), dp(4), dp(10));
            ImageView ic = new ImageView(this);
            ic.setImageDrawable(a.icon);
            r.addView(ic, new LinearLayout.LayoutParams(dp(40), dp(40)));
            TextView n = tv(a.label, 15, Color.WHITE, false);
            n.setPadding(dp(14), 0, 0, 0);
            r.addView(n);
            r.setOnClickListener(v -> {
                Profile p = new Profile();
                p.pkg = a.pkg;
                p.label = a.label;
                Store.upsert(this, p);
                gameScreen(p);
            });
            list.addView(r);
        }
    }

    // ============================================================ SETTINGS
    private void settings() {
        screen = 3;
        LinearLayout root = page();
        root.addView(back());
        root.addView(tv("Settings", 22, Color.WHITE, true), lp(dp(10)));

        root.addView(prefSwitch("In-game dock (overlay)", "overlay", true), lp(dp(14)));
        root.addView(prefSwitch("Thermal guard: lower resolution when hot", "thermal", true));
        root.addView(stepper("Thermal limit (°C)", "tlimit", 42, 36, 50, 1));
        root.addView(stepper("Auto-reset delay after leaving game (sec)", "grace", 8, 4, 30, 2));

        root.addView(tv("NEVER CLOSE THESE APPS (package names, one per line)", 11, DIM, true), lp(dp(20)));
        final EditText et = new EditText(this);
        et.setText(sp.getString("protect", ""));
        et.setTextColor(Color.WHITE);
        et.setBackground(rr(CARD, 12));
        et.setTextSize(13);
        et.setTypeface(Typeface.MONOSPACE);
        et.setPadding(dp(12), dp(10), dp(12), dp(10));
        et.setMinLines(4);
        et.setGravity(Gravity.TOP);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        et.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable e) { sp.edit().putString("protect", e.toString()).apply(); }
        });
        root.addView(et, lp(dp(6)));
        root.addView(tv("Always kept: the game, this app, Shizuku, your keyboard and your launcher. "
                + "Add e.g. a messaging app you don't want closed.", 12, DIM, false), lp(dp(6)));

        Button reset = btn("Reset phone to normal now", AMBER, Color.BLACK);
        reset.setOnClickListener(v -> resetNow());
        root.addView(reset, lp(dp(24)));

        tLog = tv("", 12, DIM, false);
        root.addView(tLog, lp(dp(10)));
        show(root);
    }

    private Switch prefSwitch(String label, final String key, boolean def) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextColor(Color.WHITE);
        s.setTextSize(14);
        s.setPadding(0, dp(9), 0, dp(9));
        s.setChecked(sp.getBoolean(key, def));
        s.setOnCheckedChangeListener((b, on) -> sp.edit().putBoolean(key, on).apply());
        return s;
    }

    private LinearLayout stepper(String label, final String key, int def, final int min, final int max, final int step) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(6), 0, dp(6));
        TextView l = tv(label, 14, Color.WHITE, false);
        row.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        final TextView val = tv(String.valueOf(sp.getInt(key, def)), 16, Color.WHITE, true);
        val.setGravity(Gravity.CENTER);
        Button minus = btn("−", CARD, Color.WHITE);
        Button plus = btn("+", CARD, Color.WHITE);
        minus.setOnClickListener(v -> {
            int n = Math.max(min, sp.getInt(key, def) - step);
            sp.edit().putInt(key, n).apply(); val.setText(String.valueOf(n));
        });
        plus.setOnClickListener(v -> {
            int n = Math.min(max, sp.getInt(key, def) + step);
            sp.edit().putInt(key, n).apply(); val.setText(String.valueOf(n));
        });
        row.addView(minus, new LinearLayout.LayoutParams(dp(44), dp(44)));
        row.addView(val, new LinearLayout.LayoutParams(dp(48), LinearLayout.LayoutParams.WRAP_CONTENT));
        row.addView(plus, new LinearLayout.LayoutParams(dp(44), dp(44)));
        return row;
    }

    // ============================================================ UI helpers
    private void log(String s) { if (tLog != null) tLog.setText(s); }

    private LinearLayout page() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(36), dp(20), dp(28));
        return root;
    }

    private void show(LinearLayout root) {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFitsSystemWindows(true);
        sv.addView(root);
        setContentView(sv);
    }

    private Button back() {
        Button b = btn("‹  Back", BG, DIM);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        b.setPadding(0, 0, 0, 0);
        b.setOnClickListener(v -> home());
        return b;
    }

    private LinearLayout card(int color) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(rr(color, 14));
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        return c;
    }

    private LinearLayout tile() {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setBackground(rr(CARD, 14));
        t.setPadding(dp(6), dp(14), dp(6), dp(12));
        return t;
    }

    private GridLayout.LayoutParams tileLp() {
        GridLayout.LayoutParams l = new GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f));
        l.width = 0;
        l.setMargins(dp(4), dp(4), dp(4), dp(4));
        return l;
    }

    private TextView tv(String s, int sz, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sz); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button btn(String s, int bg, int fg) {
        Button b = new Button(this);
        b.setText(s); b.setAllCaps(false); b.setTextColor(fg);
        b.setBackground(rr(bg, 12));
        return b;
    }

    private GradientDrawable rr(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private LinearLayout.LayoutParams lp(int top) {
        return lp(LinearLayout.LayoutParams.WRAP_CONTENT, top);
    }

    private LinearLayout.LayoutParams lp(int h, int top) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, h);
        l.topMargin = top;
        return l;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
