package com.gamelab.space;

/** One game in the library + its own tuning profile. */
final class Profile {
    String pkg;
    String label;
    int res = 1;                         // index into Engine.WIDTHS
    boolean dens = true;                 // scale density with resolution
    int flags = Engine.DEFAULT_FLAGS;    // Engine.F_* bitmask
}
