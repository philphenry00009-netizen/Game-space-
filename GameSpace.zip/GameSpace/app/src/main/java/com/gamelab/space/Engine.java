package com.gamelab.space;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ResolveInfo;
import android.provider.Settings;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Snapshot -> apply -> restore.
 * The phone's ORIGINAL values are saved to disk before the first change, so restore()
 * puts back exactly what was there, even after a reboot or an app crash.
 */
final class Engine {

    static final int F_BLUR = 1, F_ANIM = 2, F_DND = 4, F_BATT = 8, F_GAME = 16, F_SUST = 32,
            F_BRIGHT = 64, F_SCREEN = 128, F_KILL = 256, F_KILLALL = 512;
    static final int DEFAULT_FLAGS = F_BLUR | F_ANIM | F_DND | F_BATT | F_GAME | F_SUST
            | F_SCREEN | F_KILL | F_KILLALL;

    static final int[] WIDTHS = {0, 720, 540, 480, 360};
    static final String[] RES_NAMES = {"Native", "720p", "540p", "480p", "360p"};
    static final String SHIZUKU = "moe.shizuku.privileged.api";

    private static final Pattern PKG = Pattern.compile("[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+");
    private static final Pattern SIZE = Pattern.compile("(\\d+)x(\\d+)");

    private static final String SNAP =
            "echo \"OVSIZE=$(wm size | sed -n 's/^Override size: *//p')\";"
          + "echo \"PHSIZE=$(wm size | sed -n 's/^Physical size: *//p')\";"
          + "echo \"OVDEN=$(wm density | sed -n 's/^Override density: *//p')\";"
          + "echo \"PHDEN=$(wm density | sed -n 's/^Physical density: *//p')\";"
          + "echo \"blur=$(settings get global disable_window_blurs)\";"
          + "echo \"wanim=$(settings get global window_animation_scale)\";"
          + "echo \"tanim=$(settings get global transition_animation_scale)\";"
          + "echo \"danim=$(settings get global animator_duration_scale)\";"
          + "echo \"zen=$(settings get global zen_mode)\";"
          + "echo \"lowp=$(settings get global low_power)\";"
          + "echo \"adapt=$(settings get global adaptive_battery_management_enabled)\";"
          + "echo \"bmode=$(settings get system screen_brightness_mode)\";"
          + "echo \"sto=$(settings get system screen_off_timeout)\"";

    // ------------------------------------------------------------ APPLY
    static String apply(Context c, IShellService s, Profile p) throws Exception {
        if (!PKG.matcher(p.pkg).matches()) throw new IllegalArgumentException("Invalid package name");
        SharedPreferences sp = Store.sp(c);

        // Never snapshot an already-boosted phone: put it back to normal first.
        if (sp.getBoolean("active", false)) restore(c, s);

        SharedPreferences.Editor e = sp.edit();
        for (String line : s.exec(SNAP).split("\n")) {
            int i = line.indexOf('=');
            if (i > 0) e.putString("snap." + line.substring(0, i).trim(), line.substring(i + 1).trim());
        }
        e.putBoolean("active", true).putString("applied", "").putString("game", p.pkg)
                .putInt("curres", p.res).commit();

        Set<String> applied = new LinkedHashSet<>();
        StringBuilder cmd = new StringBuilder();
        resCmd(sp, WIDTHS[p.res], p.dens, cmd, applied);

        int f = p.flags;
        if ((f & F_BLUR) != 0) { cmd.append("settings put global disable_window_blurs 1; "); applied.add("blur"); }
        if ((f & F_ANIM) != 0) {
            cmd.append("settings put global window_animation_scale 0; ")
               .append("settings put global transition_animation_scale 0; ")
               .append("settings put global animator_duration_scale 0; ");
            applied.add("anim");
        }
        if ((f & F_DND) != 0) { cmd.append("cmd notification set_dnd priority; "); applied.add("dnd"); }
        if ((f & F_BATT) != 0) {
            cmd.append("settings put global low_power 0; ")
               .append("settings put global adaptive_battery_management_enabled 0; ");
            applied.add("batt");
        }
        if ((f & F_BRIGHT) != 0) { cmd.append("settings put system screen_brightness_mode 0; "); applied.add("bright"); }
        if ((f & F_SCREEN) != 0) { cmd.append("settings put system screen_off_timeout 1800000; "); applied.add("screen"); }
        if ((f & F_SUST) != 0) {
            cmd.append("cmd power set-fixed-performance-mode-enabled true 2>/dev/null; ");
            applied.add("sust");
        }
        if ((f & F_GAME) != 0) {
            // Android 12 and 13+ use different syntax; the one that doesn't apply fails silently.
            cmd.append("cmd game mode performance ").append(p.pkg).append(" 2>/dev/null; ")
               .append("cmd game set --mode performance ").append(p.pkg).append(" 2>/dev/null; ");
            applied.add("game");
        }

        sp.edit().putString("applied", join(applied)).commit();   // saved BEFORE running, so a crash is recoverable
        s.exec(cmd.toString());

        int killed = 0;
        if ((f & F_KILLALL) != 0) killed = killOthers(c, s, p.pkg);
        else if ((f & F_KILL) != 0) s.exec("am kill-all");

        s.exec("monkey -p " + p.pkg + " -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1");
        return "Boosted. " + (killed > 0 ? killed + " apps closed." : "");
    }

    // ------------------------------------------------- LIVE CHANGES
    static void setWidth(Context c, IShellService s, int idx, boolean dens) throws Exception {
        SharedPreferences sp = Store.sp(c);
        Set<String> applied = appliedSet(sp);
        StringBuilder cmd = new StringBuilder();
        resCmd(sp, WIDTHS[idx], dens, cmd, applied);
        s.exec(cmd.toString());
        sp.edit().putString("applied", join(applied)).putInt("curres", idx).commit();
    }

    static void setDnd(Context c, IShellService s, boolean on) throws Exception {
        SharedPreferences sp = Store.sp(c);
        Set<String> applied = appliedSet(sp);
        applied.add("dnd");
        s.exec("cmd notification set_dnd " + (on ? "priority" : "off"));
        sp.edit().putString("applied", join(applied)).commit();
    }

    /** Force-stops every running third-party app except the protected ones. Returns how many. */
    static int killOthers(Context c, IShellService s, String game) throws Exception {
        Set<String> keep = new HashSet<>();
        keep.add(game);
        keep.add(c.getPackageName());
        keep.add(SHIZUKU);
        for (String x : Store.sp(c).getString("protect", "").split("\\s+")) {
            if (PKG.matcher(x).matches()) keep.add(x);
        }
        Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        ResolveInfo ri = c.getPackageManager().resolveActivity(home, 0);
        if (ri != null && ri.activityInfo != null) keep.add(ri.activityInfo.packageName);
        String ime = Settings.Secure.getString(c.getContentResolver(), "default_input_method");
        if (ime != null && ime.indexOf('/') > 0) keep.add(ime.substring(0, ime.indexOf('/')));

        s.exec("am kill-all");

        Set<String> third = new HashSet<>();
        for (String l : s.exec("pm list packages -3").split("\n")) {
            l = l.trim();
            if (l.startsWith("package:")) third.add(l.substring(8));
        }
        Set<String> targets = new LinkedHashSet<>();
        for (String l : s.exec("ps -A -o NAME").split("\n")) {
            String n = l.trim();
            int colon = n.indexOf(':');
            if (colon > 0) n = n.substring(0, colon);
            if (third.contains(n) && !keep.contains(n)) targets.add(n);
        }
        if (targets.isEmpty()) return 0;

        StringBuilder sb = new StringBuilder();
        for (String t : targets) sb.append("am force-stop ").append(t).append(" & ");
        sb.append("wait");
        s.exec(sb.toString());
        return targets.size();
    }

    // ---------------------------------------------------------- RESTORE
    static String restore(Context c, IShellService s) throws Exception {
        SharedPreferences sp = Store.sp(c);
        String ap = sp.getString("applied", "");
        StringBuilder cmd = new StringBuilder();

        if (ap.isEmpty()) {
            cmd.append("wm size reset; wm density reset; ");   // safe fallback
        } else {
            Set<String> a = new HashSet<>(Arrays.asList(ap.split(",")));
            if (a.contains("size")) cmd.append(wm("size", g(sp, "OVSIZE"), "\\d+x\\d+"));
            if (a.contains("den"))  cmd.append(wm("density", g(sp, "OVDEN"), "\\d+"));
            if (a.contains("blur")) cmd.append(key("global", "disable_window_blurs", g(sp, "blur")));
            if (a.contains("anim")) {
                cmd.append(key("global", "window_animation_scale", g(sp, "wanim")))
                   .append(key("global", "transition_animation_scale", g(sp, "tanim")))
                   .append(key("global", "animator_duration_scale", g(sp, "danim")));
            }
            if (a.contains("dnd")) {
                int z = 0;
                try { z = Integer.parseInt(g(sp, "zen")); } catch (NumberFormatException ignored) {}
                String mode = z == 1 ? "priority" : z == 2 ? "none" : z == 3 ? "alarms" : "off";
                cmd.append("cmd notification set_dnd ").append(mode).append("; ");
            }
            if (a.contains("batt")) {
                cmd.append(key("global", "low_power", g(sp, "lowp")))
                   .append(key("global", "adaptive_battery_management_enabled", g(sp, "adapt")));
            }
            if (a.contains("bright")) cmd.append(key("system", "screen_brightness_mode", g(sp, "bmode")));
            if (a.contains("screen")) cmd.append(key("system", "screen_off_timeout", g(sp, "sto")));
            if (a.contains("sust"))   cmd.append("cmd power set-fixed-performance-mode-enabled false 2>/dev/null; ");
            if (a.contains("game")) {
                String game = sp.getString("game", "");
                if (PKG.matcher(game).matches()) {
                    cmd.append("cmd game mode standard ").append(game).append(" 2>/dev/null; ")
                       .append("cmd game reset ").append(game).append(" 2>/dev/null; ");
                }
            }
        }

        s.exec(cmd.toString());
        sp.edit().putBoolean("active", false).putString("applied", "").commit();
        return "Everything restored to normal.";
    }

    // ---------------------------------------------------------- helpers
    private static void resCmd(SharedPreferences sp, int width, boolean dens,
                               StringBuilder cmd, Set<String> applied) {
        if (width <= 0) {   // back to native
            cmd.append(wm("size", g(sp, "OVSIZE"), "\\d+x\\d+"));
            cmd.append(wm("density", g(sp, "OVDEN"), "\\d+"));
            return;
        }
        Matcher m = SIZE.matcher(g(sp, "PHSIZE"));
        if (!m.find()) return;
        int pw = Integer.parseInt(m.group(1)), ph = Integer.parseInt(m.group(2));
        if (pw <= width) return;
        int nh = Math.round(ph * (float) width / pw);
        nh -= nh % 2;
        cmd.append("wm size ").append(width).append('x').append(nh).append("; ");
        applied.add("size");
        if (dens) {
            try {
                int pd = Integer.parseInt(g(sp, "PHDEN"));
                int nd = Math.round(pd * (float) width / pw);
                if (nd > 0) { cmd.append("wm density ").append(nd).append("; "); applied.add("den"); }
            } catch (NumberFormatException ignored) {}
        } else {
            cmd.append(wm("density", g(sp, "OVDEN"), "\\d+"));
        }
    }

    private static String g(SharedPreferences sp, String k) { return sp.getString("snap." + k, ""); }

    private static Set<String> appliedSet(SharedPreferences sp) {
        Set<String> out = new LinkedHashSet<>();
        String a = sp.getString("applied", "");
        if (!a.isEmpty()) out.addAll(Arrays.asList(a.split(",")));
        return out;
    }

    private static String wm(String kind, String original, String regex) {
        return original.matches(regex) ? "wm " + kind + " " + original + "; " : "wm " + kind + " reset; ";
    }

    private static String key(String ns, String name, String v) {
        if (v.isEmpty() || v.equals("null") || !v.matches("[0-9A-Za-z._-]+"))
            return "settings delete " + ns + " " + name + "; ";
        return "settings put " + ns + " " + name + " " + v + "; ";
    }

    private static String join(Set<String> set) {
        StringBuilder sb = new StringBuilder();
        for (String x : set) { if (sb.length() > 0) sb.append(','); sb.append(x); }
        return sb.toString();
    }
}
